import sun
from datetime import datetime
import astral
from datetime import timedelta



FT_PER_METRE = 3.2808399

now = datetime.now()
# paramétrage de la localisation , nom du parc , pays, coordonné
parc_location = astral.Location(info=("Capespigne", "France", 43.732924, 3.251173, "GMT", 157/FT_PER_METRE))
now_hour, night_hour, sunrise_hour, night = sun.day(parc_location, now)



